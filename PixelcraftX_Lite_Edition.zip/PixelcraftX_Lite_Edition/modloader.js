function loadMods() {
  const modFiles = ["pixel_grass.js"];
  modFiles.forEach(file => {
    const script = document.createElement("script");
    script.src = "./mods/" + file;
    document.body.appendChild(script);
  });
}
window.addEventListener("load", loadMods);