registerBlock({
  id: "pixel_grass",
  displayName: "Pixel Grass",
  texture: "pixel_grass.png",
  solid: true
});