PixelcraftX Lite Edition - 初期構成パック

1. このフォルダの中身を GitHub リポジトリにアップロードしてください。
2. GitHub Pages を有効化（Settings > Pages > Source: main / root）。
3. index.html が表示され、PixelcraftX Lite Edition が起動します。
4. mods/ にファイルを追加するとブロックや要素を拡張できます。
5. assets/logo.png を好きなロゴに差し替え可能！

※ この構成は Eaglercraft 1.5.2 の軽量改造向けです。